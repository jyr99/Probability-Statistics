//
// Created by arch0n on 19-3-31.
//
#pragma once

#include <iostream>
#include <cstdint>

class arBitOstream final {
private:
    std::ostream &out;
    int32_t curByte;
    int8_t bitCount; // 当前byte中已有的bit数
public:
    uint64_t IOcount;
    explicit arBitOstream(std::ostream &out);     //
    void write(uint32_t bit);
    void finish();
};


class arBitIstream final {
private:
    std::istream &in;
    int32_t curByte;
    int8_t bitCount; // 当前byte中已有的bit数
public:
    uint64_t IOcount;
    explicit arBitIstream(std::istream &in);
    int32_t read();
};

