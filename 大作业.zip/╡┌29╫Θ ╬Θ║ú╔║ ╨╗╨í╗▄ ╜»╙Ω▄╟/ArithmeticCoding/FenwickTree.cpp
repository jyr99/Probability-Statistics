//
// Created by arch0n on 19-3-31.
//

#include "FenwickTree.h"

FenwickTree::FenwickTree(size_t sz, uint64_t val) : base(sz, val){

}

void FenwickTree::update(int id, uint64_t val) {
    for(int i = id; i < base.size(); i+=getID(i))
        base[i] += val;
}

uint64_t FenwickTree::query(int id) {
    if(id == 0)
        return 0;
    uint64_t ans = 0;
    for(; id > 0; id -= getID(id))
        ans += base[id];
    return ans;
}