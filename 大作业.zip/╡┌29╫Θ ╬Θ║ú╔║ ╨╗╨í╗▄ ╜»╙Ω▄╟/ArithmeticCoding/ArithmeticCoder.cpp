//
// Created by arch0n on 19-3-31.
//

#include "ArithmeticCoder.h"
#include <cassert>
#include <algorithm>

ArithmeticCoderBase::ArithmeticCoderBase(int32_t num) {
    assert(1<= num && num < 64);
    numStateBits = num;
    fullRange = 1ull << numStateBits;
    halfRange = fullRange >> 1u;
    quarterRange = halfRange >> 1u;
    minRange = quarterRange + 2;
    maxTotal = std::min(std::numeric_limits<uint64_t>::max() / fullRange, minRange);
    stateMask = fullRange - 1;
    low = 0;
    high = stateMask;
}

ArithmeticCoderBase::~ArithmeticCoderBase() {}

void ArithmeticCoderBase::update(FreqTable &freq, uint32_t symbol) {
    assert(low < high && (low & stateMask) == low && (high & stateMask) == high);
    uint64_t range = high - low + 1;
    assert(range >= minRange && range <= fullRange);
    uint32_t total = freq.getTotal();
    uint32_t symLow = freq.getLow(symbol);
    uint32_t symHigh = freq.getHigh(symbol);
    assert(symHigh != symLow);
    assert (total <= maxTotal);
    // Update range
    uint64_t newLow  = low + symLow  * range / total;
    uint64_t newHigh = low + symHigh * range / total - 1;
    low = newLow;
    high = newHigh;

    // While low and high have the same top bit value, shift them out
    while (((low ^ high) & halfRange) == 0) {
        shift();
        low  = ((low  << 1u) & stateMask);
        high = ((high << 1u) & stateMask) | 1;
    }
    // Now low's top bit must be 0 and high's top bit must be 1

    // While low's top two bits are 01 and high's are 10, delete the second highest bit of both
    while ((low & ~high & quarterRange) != 0) {
        underflow();
        low = (low << 1u) ^ halfRange;
        high = ((high ^ halfRange) << 1u) | halfRange | 1;
    }
}


ArithmeticDecoder::ArithmeticDecoder(int numBits, arBitIstream &bin) :
        ArithmeticCoderBase(numBits),
        in(bin),
        code(0) {
    for (int i = 0; i < numStateBits; i++)
        code = code << 1 | readCodeBit();
}


uint32_t ArithmeticDecoder::read(FreqTable &freqs) {
    uint32_t total = freqs.getTotal();
    assert(total <= maxTotal);
    uint64_t range = high - low + 1;
    uint64_t offset = code - low;
    uint64_t value = ((offset + 1) * total - 1) / range;
    assert(value * range / total <= offset);
    assert(value < total);
    uint32_t start = 0;
    uint32_t end = freqs.getSymbolLimit();
    while (end - start > 1) {
        uint32_t middle = (start + end) >> 1u;
        if (freqs.getLow(middle) > value)
            end = middle;
        else
            start = middle;
    }
    assert(start + 1 == end);
    uint32_t symbol = start;
    assert (offset >= freqs.getLow(symbol) * range / total && freqs.getHigh(symbol) * range / total > offset);
    update(freqs, symbol);
    assert(low <= code && code <= high);
    return symbol;
}


void ArithmeticDecoder::shift() {
    code = ((code << 1u) & stateMask) | readCodeBit();
}


void ArithmeticDecoder::underflow() {
    code = (code & halfRange) | ((code << 1u) & (stateMask >> 1u)) | readCodeBit();
}


int ArithmeticDecoder::readCodeBit() {
    int temp = in.read();
    if (temp == -1)
        temp = 0;
    return temp;
}


ArithmeticEncoder::ArithmeticEncoder(int numBits, arBitOstream &bout) :
        ArithmeticCoderBase(numBits),
        out(bout),
        numUnderflow(0) {}


void ArithmeticEncoder::write(FreqTable &freq, uint32_t symbol) {
    update(freq, symbol);
}


void ArithmeticEncoder::finish() {
    out.write(1);
}


void ArithmeticEncoder::shift() {
    int bit = static_cast<int>(low >> (numStateBits - 1));
    out.write(bit);

    // Write out the saved underflow bits
    for (; numUnderflow > 0; numUnderflow--)
        out.write(bit ^ 1u);
}


void ArithmeticEncoder::underflow() {
    if (numUnderflow == std::numeric_limits<decltype(numUnderflow)>::max())
        throw std::overflow_error("Maximum underflow reached");
    numUnderflow++;
}