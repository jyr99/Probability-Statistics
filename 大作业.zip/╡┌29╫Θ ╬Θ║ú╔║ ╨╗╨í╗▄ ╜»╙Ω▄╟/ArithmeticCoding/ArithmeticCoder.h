//
// Created by arch0n on 19-3-31.
//

#pragma once

#include <algorithm>
#include <cstdint>
#include "arBitIO.h"
#include "FreqTable.h"

class ArithmeticCoderBase {
protected:
    int32_t numStateBits;
    uint64_t fullRange, halfRange, quarterRange;
    uint64_t minRange, maxTotal;
    uint64_t high, low;
    uint64_t stateMask;

public:
    explicit ArithmeticCoderBase(int32_t num);
    virtual ~ArithmeticCoderBase() = 0;

protected:
    virtual void update(FreqTable &freq, uint32_t symbol);
    virtual void shift() = 0;
    virtual void underflow() = 0;
};

class ArithmeticDecoder final : private ArithmeticCoderBase {
private:
    arBitIstream &in;
    uint64_t code;
    uint64_t inSize, outSize;

public:
    explicit ArithmeticDecoder(int32_t numBits, arBitIstream &bin);
    uint32_t read(FreqTable &freq);

protected:
    void shift() override ;
    void underflow() override ;

private:
    int32_t readCodeBit();
};

class ArithmeticEncoder final : private ArithmeticCoderBase {
private:
    arBitOstream &out;
    uint32_t numUnderflow;

public:
    explicit ArithmeticEncoder(int32_t numBits, arBitOstream &out);            //
    void write(FreqTable &freq, uint32_t symbol);
    void finish();

protected:
    void shift() override ;
    void underflow() override ;
};