//
// Created by arch0n on 19-3-31.
//

#include "arBitIO.h"
#include <limits>
#include <cassert>

arBitOstream::arBitOstream(std::ostream &bout) : out(bout), curByte(0u), bitCount(0), IOcount(0) {

}

void arBitOstream::write(uint32_t bit) {
    assert(bit == 0 || bit == 1);
    curByte = (curByte << 1u) | bit;
    bitCount ++;
    IOcount ++;
    if(bitCount == 8){
        curByte &= ((1u<<8u) - 1);
        out.put(static_cast<char>(curByte));
        curByte = 0u;
        bitCount = 0;
    }
}

void arBitOstream::finish() {
    while(bitCount != 0)
        write(0u);
}

arBitIstream::arBitIstream(std::istream &bin): in(bin), curByte(0), bitCount(0),IOcount(0) {

}

int32_t arBitIstream::read() {
    if(curByte == -1)
        return -1;
    if(bitCount == 0){
        curByte = in.get();
        if(curByte == EOF)
            return  -1;
        assert(0 <= curByte && curByte <= 255);
        bitCount = 8;
    }
    assert(bitCount > 0);
    IOcount ++;
    bitCount --;
    return (curByte >> bitCount) & 1u;
}