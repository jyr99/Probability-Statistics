//
// Created by arch0n on 4/1/19.
//

#pragma once

#include "FenwickTree.h"

class FreqTable : FenwickTree{
private:
    uint64_t total;
public:
    explicit FreqTable(size_t sz, uint64_t val); //
    inline auto getTotal(){ return total;}
    uint64_t getLow(size_t id);
    uint64_t getHigh(size_t id);
    uint64_t get(size_t id);
    uint32_t getSymbolLimit();
    void inc(size_t id, uint64_t val = 1ull); //
};


