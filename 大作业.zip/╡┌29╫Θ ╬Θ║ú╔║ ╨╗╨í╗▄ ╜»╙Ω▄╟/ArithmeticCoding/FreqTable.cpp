//
// Created by arch0n on 4/1/19.
//

#include "FreqTable.h"

FreqTable::FreqTable(size_t sz, uint64_t val) : FenwickTree(sz+10, val), total(0) {

}

void FreqTable::inc(size_t id, uint64_t val) {
    if(val == 0)
        return;
    id ++;
    total += val;
    update(id, val);
}

uint64_t FreqTable::get(size_t id) {
    return query(id+1) - query(id);
}

uint64_t FreqTable::getHigh(size_t id) {
    id ++;
    return query(id);
}

uint64_t FreqTable::getLow(size_t id) {
    return query(id);
}

uint32_t FreqTable::getSymbolLimit() {
    return base.size() - 10;
}

