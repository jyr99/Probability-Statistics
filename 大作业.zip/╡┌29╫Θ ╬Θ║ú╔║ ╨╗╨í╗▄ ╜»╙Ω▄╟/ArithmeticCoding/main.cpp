#include <string>
#include <sstream>
#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstdint>
#include <string>
#include <cassert>
#include <cstring>

#include "arBitIO.h"
#include "ArithmeticCoder.h"
#include "FreqTable.h"

std::pair<uint64_t, uint64_t> doAdaptiveEncode(std::string in, std::string out);

std::pair<uint64_t, uint64_t> doAdaptiveDecode(std::string in, std::string out);

int main() {
    std::cout<<R"(To zip a file, please input in the format: "//.\ziptxt <source file name> <zip file name>")"<<std::endl
            <<R"(To unzip a file, please input in the format: "//.\unziptxt <zip file name> <unzip file name>")"<<std::endl
            <<"To exit the program, please input \"EXIT\""<<std::endl;

    while (true) {
        std::string command;
        std::cin >> command;
        if (command == ".\\ziptxt") {  //.\ziptxt <源文件名> <压缩文件名>
            std::string f1,f2;
            std::cin>>f1>>f2;
            doAdaptiveEncode(f1,f2);
            std::cout<<f1<< " successfully zipped, the zip file address is "<<f2<<std::endl;
        }
        if (command == ".\\unziptxt") {    //.\unziptxt <压缩文件名> <解压后文件名>
            std::string f1,f2;
            std::cin>>f1>>f2;
            doAdaptiveDecode(f1,f2);
            std::cout<<f1<< " successfully unzipped, the unzip file address is "<<f2<<std::endl;
        }
        if(command=="EXIT")
            break;
    }
    return 0;
}


std::pair<uint64_t, uint64_t> doAdaptiveEncode(std::string fin, std::string fout) {
    uint64_t inCount = 0;
    std::ifstream in(fin, std::ios::binary);
    std::ofstream out(fout, std::ios::binary);
    arBitOstream bout(out);
    FreqTable freq(257, 0);
    for (size_t i = 0; i <= 256; i++)
        freq.inc(i);
    ArithmeticEncoder enc(32, bout);
    while (true) {
        int symbol = in.get();
        if (symbol == EOF)
            break;
        assert(0 <= symbol && symbol <= 255);
        enc.write(freq, static_cast<uint32_t>(symbol));
        freq.inc(static_cast<uint32_t>(symbol));
        inCount++;
    }
    enc.write(freq, 256);
    enc.finish();
    bout.finish();
    inCount *= 8;
    return {inCount, bout.IOcount};
}

std::pair<uint64_t, uint64_t> doAdaptiveDecode(std::string fin, std::string fout) {
    uint64_t outCount = 0;
    std::ifstream in(fin, std::ios::binary);
    std::ofstream out(fout, std::ios::binary);
    arBitIstream bin(in);
    FreqTable freq(257, 0);
    for (size_t i = 0; i <= 256; i++)
        freq.inc(i);
    ArithmeticDecoder dec(32, bin);
    while (true) {
        uint32_t symbol = dec.read(freq);
        if (symbol == 256)
            break;
        int b = static_cast<int>(symbol);
        out.put(static_cast<char>(b));
        outCount++;
        freq.inc(symbol);
    }
    outCount *= 8;
    return {bin.IOcount, outCount};
}
