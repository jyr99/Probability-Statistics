//
// Created by arch0n on 19-3-31.
//
#pragma once

#include <vector>
#include <cstdint>


class FenwickTree {
private:
    inline int getID(int x){return x&(-x);}

protected:
    std::vector<uint64_t> base;
    inline auto at(size_t id){return base.at(id);}
    void update(int id, uint64_t val);                 //
    uint64_t query(int id);

public:
    explicit FenwickTree(size_t sz, uint64_t val);     //
};
