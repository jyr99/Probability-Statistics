#ifndef _ZIP_H_
#define _ZIP_H_

#include <vector>
#include <queue>
#include <utility>
using namespace std;

#define GET_BYTE(vbyte, index) (((vbyte) & (1 << ((index) ^ 7))) != 0)
#define SET_BYTE(vbyte, index) ((vbyte) |= (1 << ((index) ^ 7)))
#define CLR_BYTE(vbyte, index) ((vbyte) &= (~(1 << ((index) ^ 7))))
#define NOT_INIT		-1

struct HUF_FILE_HEAD {
	unsigned char flag[3];				//压缩二进制文件头部标志 ycy
	unsigned char alphaVariety;		//字符种类
	unsigned char lastValidBit;		//最后一个字节的有效位数
	unsigned char unused[11];			//待用空间
};								//这个结构体总共占用16个字节的空间

struct ALPHA_FREQ {
	unsigned char alpha;		//字符,考虑到文件中有汉字，所以定义成unsigned char
	int freq;								//字符出现的频度
};

struct HUFFMAN_TAB {
	ALPHA_FREQ alphaFreq;
	int leftChild;
	int rightChild;
	bool visited;
	char * code;
};

struct cmp {
    bool operator() (pair<int,int> a, pair<int,int> b) {
        return a.first > b.first; //小顶堆
    }
};

class HUFFMAN{
public:
    HUFFMAN();
    ~HUFFMAN();

    int getVariety();

    void getAlphaFreq(char *sourceFileName);//ziptxt
    void initHuffmanTab();
    int getMinFreq(int count);
    void huffmanEncoding(char *sourceFileName, char *targetFileName);
    int getlastValidBit();

    void getAlphaFreq(char *sourceFileName, HUF_FILE_HEAD fileHead);//unziptxt
    void creatHuffmanTree();
    void makeHuffmanCode(int root, int index, char *code);
    void huffmanDecoding(char *sourceFileName, char *targetFileName, HUF_FILE_HEAD fileHead);

private:
    ALPHA_FREQ *alphaFreq;
    HUFFMAN_TAB *huffmanTab;
    int alphaVariety;
    int hufIndex[256];
    priority_queue<pair<int,int>,vector<pair<int,int> >,cmp> q;
    //first为频率，second为在表中的下标
};

bool isFileExist(char *fileName);
HUF_FILE_HEAD readFileHead(char *sourceFileName);

#endif
