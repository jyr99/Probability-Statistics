#pragma pack(push)
#pragma pack(1)		//内存对其改为1个字节对齐模式

#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include <string>
#include <vector>
#include <queue>
#include <utility>
#include "zip_and_unzip.h"
using namespace std;

HUFFMAN::HUFFMAN() {
    alphaFreq = NULL;
    huffmanTab = NULL;
    alphaVariety = 0;

    for(int i = 0; i < 256; i++)
        hufIndex[i] = 0;
}

HUFFMAN::~HUFFMAN() {
	for(int i = 0; i < alphaVariety; i++) {
		delete []huffmanTab[i].code;
	}

	delete []huffmanTab;
	delete []alphaFreq;
}

int HUFFMAN::getVariety() {return alphaVariety;}

//取最后一个字节的有效位数
int HUFFMAN::getlastValidBit() {
	int sum = 0;
	for(int i = 0; i < alphaVariety; i++) {
		sum += strlen(huffmanTab[i].code) * huffmanTab[i].alphaFreq.freq;
		sum &= 0xFF;
	}
	sum &= 0x7;

	return sum == 0 ? 8 : sum;
}

void HUFFMAN::huffmanEncoding(char *sourceFileName, char *targetFileName) {
	FILE *fpIn;
	FILE *fpOut;
	int ch;
	unsigned char value;
	int bitIndex = 0;
	char *hufCode = NULL;
	HUF_FILE_HEAD fileHead = {'t', 'x', 't'};

	fpIn = fopen(sourceFileName, "rb");
	fpOut = fopen(targetFileName, "wb");

	fileHead.alphaVariety = (unsigned char) alphaVariety;
	fileHead.lastValidBit = getlastValidBit();

	fwrite(&fileHead, sizeof(HUF_FILE_HEAD), 1, fpOut);
	fwrite(alphaFreq, sizeof(ALPHA_FREQ), alphaVariety, fpOut);

	ch = fgetc(fpIn);
	while(!feof(fpIn)) {
		hufCode = huffmanTab[hufIndex[ch]].code;
		for(int i = 0; hufCode[i]; i++) {
			if(hufCode[i] == '0') {
				CLR_BYTE(value, bitIndex);
			}
			else SET_BYTE(value, bitIndex);
			bitIndex++;
			if(bitIndex >= 8) {
				bitIndex = 0;
				fwrite(&value, sizeof(unsigned char), 1, fpOut);
			}
		}
		ch = fgetc(fpIn);
	}
	if(bitIndex) {
		fwrite(&value, sizeof(unsigned char), 1, fpOut);
	}

	fclose(fpIn);
	fclose(fpOut);
}

void HUFFMAN::makeHuffmanCode(int root, int index, char *code) {
	if(huffmanTab[root].leftChild != -1 && huffmanTab[root].rightChild != -1) {
		code[index] = '1';
		makeHuffmanCode(huffmanTab[root].leftChild, index + 1, code);
		code[index] = '0';
		makeHuffmanCode(huffmanTab[root].rightChild, index + 1, code);
	} else {
		code[index] = 0;
		strcpy(huffmanTab[root].code, code);
	}
}

void HUFFMAN::creatHuffmanTree() {
	int leftChild,rightChild;
	for(int i = 0; i < alphaVariety - 1; i++) {
		leftChild = getMinFreq(alphaVariety + i);
		rightChild = getMinFreq(alphaVariety + i);
		huffmanTab[alphaVariety + i].alphaFreq.alpha = ' ';
		huffmanTab[alphaVariety + i].alphaFreq.freq = huffmanTab[leftChild].alphaFreq.freq + huffmanTab[rightChild].alphaFreq.freq;

		int sum=huffmanTab[leftChild].alphaFreq.freq + huffmanTab[rightChild].alphaFreq.freq;
		q.push(make_pair(sum,alphaVariety+i));

		huffmanTab[alphaVariety + i].leftChild = leftChild;
		huffmanTab[alphaVariety + i].rightChild = rightChild;
		huffmanTab[alphaVariety + i].visited = 0;
	}
}

//在哈夫曼表中找没有访问过的最小频度下标
int HUFFMAN::getMinFreq(int count) {
    int minIndex=q.top().second;
    q.pop();
    return minIndex;

    /*
	int minIndex = NOT_INIT;

	for(int i = 0; i < count; i++) {
		if(huffmanTab[i].visited == 0) {
			if(NOT_INIT == minIndex || huffmanTab[i].alphaFreq.freq < huffmanTab[minIndex].alphaFreq.freq) {
				minIndex = i;
			}
		}
	}
	huffmanTab[minIndex].visited = 1;

	return minIndex;
	*/
}

void HUFFMAN::initHuffmanTab() {
	huffmanTab = new HUFFMAN_TAB[2 * alphaVariety - 1];
	//huffmanTab申请了 2 * alphaVariety - 1大小的空间，
	//在这只用了 alphaVariety个，还剩alphaVariety - 1个
	for(int i = 0; i < alphaVariety; i++) {
		hufIndex[alphaFreq[i].alpha] = i;	//把哈夫曼表中的字符和其对应的下标形成键值对,存到hufIndex中
		huffmanTab[i].alphaFreq = alphaFreq[i];
		huffmanTab[i].leftChild = huffmanTab[i].rightChild = -1;
		huffmanTab[i].visited = 0;
		huffmanTab[i].code = new char[alphaVariety];

		q.push(make_pair(huffmanTab[i].alphaFreq.freq,i));
	}
}

void HUFFMAN::getAlphaFreq(char *sourceFileName) {
	int freq[256] = {0};
	int index = 0;
	FILE *fpIn;
	int ch;

	fpIn = fopen(sourceFileName, "rb");

	/*统计所有字符的频度*/
	ch = fgetc(fpIn);
	while(!feof(fpIn)) {
		freq[ch]++;
		ch = fgetc(fpIn);
	}
	fclose(fpIn);

	//统计所有字符的种类
	for(int i = 0; i < 256; i++) {
		if(freq[i]) alphaVariety++;
	}

	alphaFreq = new ALPHA_FREQ[alphaVariety];

	for(int i = 0; i < 256; i++) {
		if(freq[i]) {
			alphaFreq[index].alpha = i;
			alphaFreq[index].freq = freq[i];
			index++;
		}
	}
}

bool isFileExist(char *fileName) {
	FILE *fp;
	fp = fopen(fileName, "rb");
	if (fp == NULL) return 0;
	fclose(fp);
	return 1;
}

int main(int argc, char const *argv[]) {
	char sourceFileName[256] = {0};
	char targetFileName[256] = {0};

	HUFFMAN myHuffman;
	char *code = NULL;						//存储字符的哈夫曼编码

	if(argc != 3) {
		cout << "正确命令格式: .\\ziptxt <源文件名> <目标文件名>" << endl;
		return 0;
	}

	//第二个参数为源文件名
	strcpy(sourceFileName, argv[1]);
	strcpy(targetFileName, argv[2]);
	if(!isFileExist(sourceFileName)) {
		cout << "源文件" << sourceFileName << "不存在！" << endl;
		return 0;
	}

	myHuffman.getAlphaFreq(sourceFileName);
	myHuffman.initHuffmanTab();
	myHuffman.creatHuffmanTree();
	code = new char[myHuffman.getVariety()];
	myHuffman.makeHuffmanCode(2 * myHuffman.getVariety() - 2, 0, code);
	myHuffman.huffmanEncoding(sourceFileName, targetFileName);

	delete []code;

	cout << sourceFileName << "文件压缩成功，压缩文件地址为" << targetFileName << endl;

	return 0;
}

#pragma pack(pop)
