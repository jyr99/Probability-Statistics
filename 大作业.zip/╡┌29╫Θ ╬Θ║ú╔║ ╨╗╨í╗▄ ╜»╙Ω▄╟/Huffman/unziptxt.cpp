#pragma pack(push)
#pragma pack(1)		//内存对其改为1个字节对齐模式

#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include <vector>
#include <queue>
#include <utility>
#include "zip_and_unzip.h"
using namespace std;

HUFFMAN::HUFFMAN() {
    alphaFreq = NULL;
    huffmanTab = NULL;
    alphaVariety = 0;

    for(int i = 0; i < 256; i++)
        hufIndex[i] = 0;
}

HUFFMAN::~HUFFMAN() {
	for(int i = 0; i < alphaVariety; i++) {
		delete []huffmanTab[i].code;
	}

	delete []huffmanTab;
	delete []alphaFreq;
}


int HUFFMAN::getVariety() {return alphaVariety;}

void HUFFMAN::huffmanDecoding(char *sourceFileName, char *targetFileName, HUF_FILE_HEAD fileHead) {
	int root = 2 * alphaVariety - 2;
	FILE *fpIn;
	FILE *fpOut;
	bool finished = 0;
	unsigned char value;
	unsigned char outValue;
	int index = 0;
	long fileSize;
	long curLocation;

	fpIn = fopen(sourceFileName, "rb");
	fpOut = fopen(targetFileName, "wb");
	fseek(fpIn, 0L, SEEK_END);
	fileSize = ftell(fpIn);	//文件总长度fileSize
	fseek(fpIn, 16 + 5 * fileHead.alphaVariety, SEEK_SET);	//略过前面16个字节的元数据，5字节的字符种类和频度
	curLocation = ftell(fpIn);

	//从根出发，'1'向左子树走，'0'向右子树走，若到达叶子结点，输出叶子结点下标对应的字符。再回到根结点继续。
	fread(&value, sizeof(unsigned char), 1, fpIn);
	while(!finished) {
		if(huffmanTab[root].leftChild == -1 && huffmanTab[root].rightChild == -1) {
			outValue = huffmanTab[root].alphaFreq.alpha;
			fwrite(&outValue, sizeof(unsigned char), 1, fpOut);
			if(curLocation >= fileSize && index >= fileHead.lastValidBit) {
				break;
			}
			root = 2 * alphaVariety - 2;
		}

		//取出的一个字节从第一位开始看，'1'向左子树走，'0'向右子树走
		//若超过一个字节，8位，则需要读取下一个字节
		if(GET_BYTE(value, index)) {
			root = huffmanTab[root].leftChild;
		} else {
			root = huffmanTab[root].rightChild;
		}
		if(++index >= 8) {
			index = 0;
			fread(&value, sizeof(unsigned char), 1, fpIn);
			curLocation = ftell(fpIn);
		}
	}

	fclose(fpIn);
	fclose(fpOut);
}

HUF_FILE_HEAD readFileHead(char *sourceFileName) {
	HUF_FILE_HEAD fileHead;
	FILE *fp;

	fp = fopen(sourceFileName, "rb");
	//读取压缩的文件的头部元数据，16个字节
	fread(&fileHead, sizeof(HUF_FILE_HEAD), 1, fp);
	fclose(fp);

	return fileHead;
}

void HUFFMAN::makeHuffmanCode(int root, int index, char *code) {
	if(huffmanTab[root].leftChild != -1 && huffmanTab[root].rightChild != -1) {
		code[index] = '1';
		makeHuffmanCode(huffmanTab[root].leftChild, index + 1, code);
		code[index] = '0';
		makeHuffmanCode(huffmanTab[root].rightChild, index + 1, code);
	} else {
		code[index] = 0;
		strcpy(huffmanTab[root].code, code);
	}
}

void HUFFMAN::creatHuffmanTree() {
	int leftChild,rightChild;

	//huffmanTab使用剩下的 alphaVariety - 1个空间
	for(int i = 0; i < alphaVariety - 1; i++) {
		leftChild = getMinFreq(alphaVariety + i);
		rightChild = getMinFreq(alphaVariety + i);
		huffmanTab[alphaVariety + i].alphaFreq.alpha = ' ';
		huffmanTab[alphaVariety + i].alphaFreq.freq = huffmanTab[leftChild].alphaFreq.freq + huffmanTab[rightChild].alphaFreq.freq;
		huffmanTab[alphaVariety + i].leftChild = leftChild;
		huffmanTab[alphaVariety + i].rightChild = rightChild;
		huffmanTab[alphaVariety + i].visited = 0;

		int sum=huffmanTab[leftChild].alphaFreq.freq + huffmanTab[rightChild].alphaFreq.freq;
		q.push(make_pair(sum,alphaVariety+i));
	}
}

//在哈夫曼表中找没有访问过的最小频度下标
int HUFFMAN::getMinFreq(int count) {
    int minIndex=q.top().second;
    q.pop();
    return minIndex;

    /*
	int minIndex = NOT_INIT;

	for(int i = 0; i < count; i++) {
		if(huffmanTab[i].visited == 0) {
			if(NOT_INIT == minIndex || huffmanTab[i].alphaFreq.freq < huffmanTab[minIndex].alphaFreq.freq) {
				minIndex = i;
			}
		}
	}
	huffmanTab[minIndex].visited = 1;

	return minIndex;
	*/
}

void HUFFMAN::initHuffmanTab() {
	huffmanTab = new HUFFMAN_TAB[2 * alphaVariety - 1];
	//huffmanTab申请了 2 * alphaVariety - 1大小的空间，
	//在这只用了 alphaVariety个，还剩alphaVariety - 1个
	for(int i = 0; i < alphaVariety; i++) {
		hufIndex[alphaFreq[i].alpha] = i;	//把哈夫曼表中的字符和其对应的下标形成键值对,存到hufIndex中
		huffmanTab[i].alphaFreq = alphaFreq[i];
		huffmanTab[i].leftChild = huffmanTab[i].rightChild = -1;
		huffmanTab[i].visited = 0;
		huffmanTab[i].code = new char[alphaVariety];

		q.push(make_pair(huffmanTab[i].alphaFreq.freq,i));
	}
}

void HUFFMAN::getAlphaFreq(char *sourceFileName, HUF_FILE_HEAD fileHead) {
	FILE *fpIn;
	alphaVariety = fileHead.alphaVariety;
	alphaFreq = new ALPHA_FREQ[alphaVariety];

	fpIn = fopen(sourceFileName, "rb");
	//略过前16个字节的元数据
	fseek(fpIn, 16, SEEK_SET);
	fread(alphaFreq, sizeof(ALPHA_FREQ), alphaVariety, fpIn);
	fclose(fpIn);
}

bool isFileExist(char *fileName) {
	FILE *fp;
	fp = fopen(fileName, "rb");
	if (fp == NULL) return 0;
	fclose(fp);
	return 1;
}

int main(int argc, char const *argv[]) {
	char sourceFileName[256] = {0};
	char targetFileName[256] = {0};

	HUFFMAN myHuffman;
	char *code = NULL;									//存储字符的哈夫曼编码
	HUF_FILE_HEAD fileHead;

	if(argc != 3) {
		cout << "正确命令格式:.\\unziptxt <源文件名> <目标文件名>" << endl;
		return 0;
	}

	strcpy(sourceFileName, argv[1]);
	strcpy(targetFileName, argv[2]);
	if(!isFileExist(sourceFileName)) {
		cout << "源文件" << sourceFileName << "不存在！" << endl;
		return 0;
	}
	fileHead = readFileHead(sourceFileName);
	if(!(fileHead.flag[0] == 't' && fileHead.flag[1] == 'x' && fileHead.flag[2] == 't')) {
		cout << "不可识别的文件格式" << endl;
	}

	myHuffman.getAlphaFreq(sourceFileName, fileHead);
	myHuffman.initHuffmanTab();
	myHuffman.creatHuffmanTree();

	code = new char[myHuffman.getVariety()];
	myHuffman.makeHuffmanCode(2 * myHuffman.getVariety() - 2, 0, code);
	myHuffman.huffmanDecoding(sourceFileName, targetFileName, fileHead);

    delete []code;
	cout << sourceFileName << "文件解压成功，解压后文件地址为" << targetFileName << endl;

	return 0;
}

#pragma pack(pop)
